file=open("registro_acciones.txt","r")
for item in file:
    print (item)
file.close()
