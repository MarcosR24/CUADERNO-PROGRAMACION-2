import ledb
import ledbo
import flbutton
import flbod

ledb.ledbt()
ledb.control_led()
print ("Listo")

ledbo.ledbort()
ledbo.con_led()
print (" Listo")

flbutton.ledb()
flbutton.controlar_led()
print ("Listo")

flbod.led()
flbod.co_led()
print (" POR FINNN....")
