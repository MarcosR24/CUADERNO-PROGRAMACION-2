import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(12,GPIO.OUT)

while True:
      GPIO.output(12,True)
      time.sleep(1)
      GPIO.output(12, False)
      time.sleep(1)
